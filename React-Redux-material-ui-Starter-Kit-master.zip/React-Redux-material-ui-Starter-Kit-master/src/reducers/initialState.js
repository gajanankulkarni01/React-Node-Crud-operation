export default {
    numAjaxCallsInProgress: 0,
};
